"use client"

import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export function RoomTypeSelector() {
  return (
    <Select>
      <SelectTrigger className="w-full">
        <SelectValue placeholder="Select room type" />
      </SelectTrigger>
      <SelectContent>
        <SelectGroup>
          <SelectLabel>Room Types</SelectLabel>
          <SelectItem value="deluxe">Deluxe Room</SelectItem>
          <SelectItem value="executive">Executive Suite</SelectItem>
          <SelectItem value="presidential">Presidential Suite</SelectItem>
          <SelectItem value="family">Family Room</SelectItem>
        </SelectGroup>
      </SelectContent>
    </Select>
  )
}

