"use client"

import { useState } from "react"
import Image from "next/image"
import { Check, ChevronDown } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

type Language = {
  code: string
  name: string
  flag: string
}

const languages: Language[] = [
  {
    code: "en",
    name: "English",
    flag: "/placeholder.svg?height=20&width=30&text=🇺🇸",
  },
  {
    code: "es",
    name: "Español",
    flag: "/placeholder.svg?height=20&width=30&text=🇪🇸",
  },
  {
    code: "fr",
    name: "Français",
    flag: "/placeholder.svg?height=20&width=30&text=🇫🇷",
  },
  {
    code: "de",
    name: "Deutsch",
    flag: "/placeholder.svg?height=20&width=30&text=🇩🇪",
  },
  {
    code: "zh",
    name: "中文",
    flag: "/placeholder.svg?height=20&width=30&text=🇨🇳",
  },
  {
    code: "ja",
    name: "日本語",
    flag: "/placeholder.svg?height=20&width=30&text=🇯🇵",
  },
  {
    code: "ar",
    name: "العربية",
    flag: "/placeholder.svg?height=20&width=30&text=🇸🇦",
  },
  {
    code: "ru",
    name: "Русский",
    flag: "/placeholder.svg?height=20&width=30&text=🇷🇺",
  },
]

interface LanguageSwitcherProps {
  className?: string
}

export function LanguageSwitcher({ className }: LanguageSwitcherProps) {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(languages[0])

  const handleLanguageChange = (language: Language) => {
    setCurrentLanguage(language)
    // In a real application, you would implement language switching logic here
    // This might involve setting a cookie, updating localStorage, or calling an API
    console.log(`Language changed to ${language.name}`)
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className={cn("flex items-center gap-1 px-2", className)}
          aria-label="Select language"
        >
          <Image
            src={currentLanguage.flag || "/placeholder.svg"}
            alt={currentLanguage.name}
            width={20}
            height={15}
            className="rounded-sm"
          />
          <span className="hidden sm:inline-block ml-1">{currentLanguage.name}</span>
          <ChevronDown className="h-4 w-4 opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[180px]">
        {languages.map((language) => (
          <DropdownMenuItem
            key={language.code}
            className={cn(
              "flex items-center gap-2 cursor-pointer",
              currentLanguage.code === language.code && "bg-muted",
            )}
            onClick={() => handleLanguageChange(language)}
          >
            <Image
              src={language.flag || "/placeholder.svg"}
              alt={language.name}
              width={20}
              height={15}
              className="rounded-sm"
            />
            <span className="flex-1">{language.name}</span>
            {currentLanguage.code === language.code && <Check className="h-4 w-4" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

